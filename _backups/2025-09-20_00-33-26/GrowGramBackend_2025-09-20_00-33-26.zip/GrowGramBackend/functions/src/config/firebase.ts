// Robust für Emulator + Prod, keine eigenen Credentials nötig.
import * as admin from 'firebase-admin';
import * as functions from 'firebase-functions';

type FxCfg = { storage?: { bucket?: string } };
const fxCfg = ((functions as unknown as { config?: () => FxCfg }).config?.() ?? {}) as FxCfg;

// FIREBASE_CONFIG (vom Emulator/Runtime gesetzt)
function readFirebaseConfig(): { projectId?: string; storageBucket?: string } {
  try { const raw = process.env.FIREBASE_CONFIG; if (raw) return JSON.parse(raw); } catch {}
  return {};
}
const fbc = readFirebaseConfig();

function resolveBucket(projectId?: string): string | undefined {
  if (fbc.storageBucket) return fbc.storageBucket;
  if (fxCfg?.storage?.bucket) return String(fxCfg.storage.bucket);
  return projectId ? `${projectId}.appspot.com` : undefined;
}

// 👉 kein admin.apps.length – stattdessen try/catch
let initialized = true;
try { admin.app(); } catch { initialized = false; }
if (!initialized) admin.initializeApp();

const projectId =
  admin.app().options.projectId ||
  fbc.projectId ||
  process.env.GCLOUD_PROJECT ||
  process.env.GOOGLE_CLOUD_PROJECT ||
  '';

export const bucketName = resolveBucket(projectId);

// Firestore QoL
const firestore = admin.firestore();
firestore.settings({ ignoreUndefinedProperties: true });

export { admin };
export const db = firestore;
export const auth = admin.auth();
export const bucket = admin.storage().bucket(bucketName || undefined);